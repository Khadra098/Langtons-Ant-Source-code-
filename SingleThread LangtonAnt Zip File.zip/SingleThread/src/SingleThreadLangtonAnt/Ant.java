package SingleThreadLangtonAnt;


import java.awt.*;

public class Ant {
    public int x, y, direction;
    public final Color color;

    public Ant(int x, int y, Color color) {
        this.x = x;
        this.y = y;
        this.direction = 0;
        this.color = color;
    }
}
