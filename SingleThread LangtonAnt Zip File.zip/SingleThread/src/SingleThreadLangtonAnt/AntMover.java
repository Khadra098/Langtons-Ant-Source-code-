package SingleThreadLangtonAnt;



import java.util.List;

public class AntMover {
    private final GridManager gridManager;

    public AntMover(GridManager gridManager) {
        this.gridManager = gridManager;
    }

    public void moveAnts(List<Ant> ants) {
        for (Ant ant : ants) {
            gridManager.moveAnt(ant);
        }
    }
}
