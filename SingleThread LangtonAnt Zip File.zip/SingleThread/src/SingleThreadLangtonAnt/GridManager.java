package SingleThreadLangtonAnt;

import java.awt.*;
import java.util.HashMap;

public class GridManager {
    private final int gridSize;

    public record CellKey(int x, int y) {}

    private final HashMap<CellKey, Boolean> grid = new HashMap<>();
    private final HashMap<CellKey, Color> coloredGrid = new HashMap<>();
    private final HashMap<CellKey, Integer> antPositions = new HashMap<>();

    public GridManager(int gridSize) {
        this.gridSize = gridSize;
    }

    public void moveAnt(Ant ant) {
        CellKey key = new CellKey(ant.x, ant.y);
        boolean isBlack = grid.getOrDefault(key, false);

        if (antPositions.containsKey(key)) {
            ant.direction = Direction.turnAround(ant.direction);
        } else {
            antPositions.put(key, ant.direction);
        }

        ant.direction = isBlack ? Direction.turnRight(ant.direction) : Direction.turnLeft(ant.direction);
        grid.put(key, !isBlack);

        if (!isBlack) {
            coloredGrid.put(key, ant.color);
        }

        // Move ant
        switch (ant.direction) {
            case Direction.UP -> ant.y = (ant.y - 1 + gridSize) % gridSize;
            case Direction.RIGHT -> ant.x = (ant.x + 1) % gridSize;
            case Direction.DOWN -> ant.y = (ant.y + 1) % gridSize;
            case Direction.LEFT -> ant.x = (ant.x - 1 + gridSize) % gridSize;
        }

        CellKey newKey = new CellKey(ant.x, ant.y);
        antPositions.put(newKey, ant.direction);
    }

    public HashMap<CellKey, Boolean> getGrid() {
        return grid;
    }

    public HashMap<CellKey, Color> getColoredGrid() {
        return coloredGrid;
    }

    public HashMap<CellKey, Integer> getAntPositions() {
        return antPositions;
    }
}

