package SingleThreadLangtonAnt;




import javax.swing.*;
import java.awt.*;
import java.util.List;

public class LangtonsAntPanel extends JPanel {
    private final int gridSize;
    private final GridManager gridManager;
    private final List<Ant> ants;

    public LangtonsAntPanel(int gridSize, GridManager gridManager, List<Ant> ants) {
        this.gridSize = gridSize;
        this.gridManager = gridManager;
        this.ants = ants;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int panelWidth = getWidth();
        int panelHeight = getHeight();

        double scaleX = (double) panelWidth / gridSize;
        double scaleY = (double) panelHeight / gridSize;

        for (var entry : gridManager.getGrid().entrySet()) {
            GridManager.CellKey key = entry.getKey();
            boolean isBlack = entry.getValue();
            int x = key.x();
            int y = key.y();
            g.setColor(isBlack ? gridManager.getColoredGrid().getOrDefault(key, Color.BLACK) : Color.WHITE);
            g.fillRect((int) (x * scaleX), (int) (y * scaleY), (int) Math.ceil(scaleX), (int) Math.ceil(scaleY));
        }

        for (Ant ant : ants) {
            g.setColor(ant.color);
            g.fillRect((int) (ant.x * scaleX), (int) (ant.y * scaleY), (int) Math.ceil(scaleX), (int) Math.ceil(scaleY));
        }
    }
}
