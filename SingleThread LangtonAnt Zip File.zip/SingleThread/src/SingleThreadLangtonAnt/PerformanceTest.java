package SingleThreadLangtonAnt;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PerformanceTest {
    public static void main(String[] args) {
        int gridSize = 10000;
        int steps = 5000;
        int[] antCounts = {1, 10, 100, 500};

        System.out.println("=== Single-Threaded Performance Test ===");
        System.out.printf("Grid Size: %dx%d, Steps: %d%n", gridSize, gridSize, steps);
        System.out.println("----------------------------------------");

        for (int antCount : antCounts) {
            // Setup
            GridManager gridManager = new GridManager(gridSize);
            List<Ant> ants = new ArrayList<>();
            for (int i = 0; i < antCount; i++) {
                ants.add(new Ant(
                    (int) (Math.random() * gridSize),
                    (int) (Math.random() * gridSize),
                    new Color((int) (Math.random() * 0x1000000))
                ));
            }

            AntMover antMover = new AntMover(gridManager);
            SingleThreadEngine engine = new SingleThreadEngine(gridSize, ants, antMover);

            // Timing
            long start = System.currentTimeMillis();
            for (int i = 0; i < steps; i++) {
                engine.step();
                if ((i + 1) % 1000 == 0) {
                    System.out.printf("  [%d ants] Step %d completed...%n", antCount, i + 1);
                }
            }
            long end = System.currentTimeMillis();
            long duration = end - start;

            // Output
            System.out.printf("Ants: %4d | Total Time: %5d ms | Avg per step: %.2f ms%n",
                antCount, duration, duration / (double) steps);
        }

        System.out.println("----------------------------------------");
        System.out.println("Test complete.");
    }
}

