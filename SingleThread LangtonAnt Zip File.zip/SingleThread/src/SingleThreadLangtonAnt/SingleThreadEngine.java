package SingleThreadLangtonAnt;



import java.util.List;

public class SingleThreadEngine {
    private final int gridSize;
    private final List<Ant> ants;
    private final AntMover antMover;

    public SingleThreadEngine(int gridSize, List<Ant> ants, AntMover antMover) {
        this.gridSize = gridSize;
        this.ants = ants;
        this.antMover = antMover;
    }

    public void step() {
        antMover.moveAnts(ants);
    }
}
