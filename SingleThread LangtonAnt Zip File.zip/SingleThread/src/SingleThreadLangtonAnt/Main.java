package SingleThreadLangtonAnt;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static int speed = 15; // Faster update interval
    private static int stepsPerTick = 20; // More simulation steps per tick
    private static Timer timer;
    private static boolean isPaused = false;
    private static List<Ant> ants;
    private static GridManager gridManager;
    private static SingleThreadEngine engine;

    public static void main(String[] args) {
        // Prompt user for configuration
        String gridSizeInput = JOptionPane.showInputDialog("Enter grid size (e.g., 500):", "500");
        String antCountInput = JOptionPane.showInputDialog("Enter number of ants (e.g., 1):", "1");
        String totalStepsInput = JOptionPane.showInputDialog("Enter number of simulation steps (e.g., 10000):", "10000");

        int gridSize = Integer.parseInt(gridSizeInput);
        int numAnts = Integer.parseInt(antCountInput);
        int totalSteps = Integer.parseInt(totalStepsInput);
        int[] stepCounter = {0};

        gridManager = new GridManager(gridSize);
        ants = new ArrayList<>();

        for (int i = 0; i < numAnts; i++) {
            int x = gridSize / 2;
            int y = gridSize / 2;
            Color color = new Color((int) (Math.random() * 0x1000000));
            ants.add(new Ant(x, y, color));
        }

        AntMover antMover = new AntMover(gridManager);
        engine = new SingleThreadEngine(gridSize, ants, antMover);

        LangtonsAntPanel panel = new LangtonsAntPanel(gridSize, gridManager, ants);
        JFrame frame = new JFrame("Langton's Ant - Single Threaded");
        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.CENTER);
        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        createControlPanel(gridSize);

        timer = new Timer(speed, e -> {
            if (!isPaused && stepCounter[0] < totalSteps) {
                for (int i = 0; i < stepsPerTick && stepCounter[0] < totalSteps; i++) {
                    engine.step();
                    stepCounter[0]++;
                }
                SwingUtilities.invokeLater(panel::repaint); // Prevent GUI blocking
            }
        });
        timer.start();
    }

    private static void createControlPanel(int gridSize) {
        JFrame controlFrame = new JFrame("Controls");
        controlFrame.setLayout(new FlowLayout());

        JButton addAntButton = new JButton("Add Ant");
        addAntButton.addActionListener(e -> {
            int x = (int) (Math.random() * gridSize);
            int y = (int) (Math.random() * gridSize);
            Color color = new Color((int) (Math.random() * 0x1000000));
            ants.add(new Ant(x, y, color));
        });

        JButton removeAntButton = new JButton("Remove Ant");
        removeAntButton.addActionListener(e -> {
            if (ants.size() > 1) {
                ants.remove(ants.size() - 1);
            } else {
                JOptionPane.showMessageDialog(null, "At least one ant must remain.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        });

        JButton speedUpButton = new JButton("Speed Up");
        speedUpButton.addActionListener(e -> {
            if (speed > 5) {
                speed -= 5;
                timer.setDelay(speed);
            }
        });

        JButton slowDownButton = new JButton("Slow Down");
        slowDownButton.addActionListener(e -> {
            if (speed < 200) {
                speed += 5;
                timer.setDelay(speed);
            }
        });

        JButton pauseButton = new JButton("Pause / Resume");
        pauseButton.addActionListener(e -> isPaused = !isPaused);

        JButton stopButton = new JButton("Stop");
        stopButton.addActionListener(e -> {
            timer.stop();
            ants.clear();
        });

        controlFrame.add(addAntButton);
        controlFrame.add(removeAntButton);
        controlFrame.add(speedUpButton);
        controlFrame.add(slowDownButton);
        controlFrame.add(pauseButton);
        controlFrame.add(stopButton);

        controlFrame.setSize(600, 100);
        controlFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        controlFrame.setVisible(true);
    }
}

