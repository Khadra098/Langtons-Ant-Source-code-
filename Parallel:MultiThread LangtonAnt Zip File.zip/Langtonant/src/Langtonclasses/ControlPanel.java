package Langtonclasses;


import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ControlPanel {
 public static void create(JFrame frame, List<Ant> ants, Runnable addAnt, Runnable removeAnt, Runnable togglePause, int initialSteps, java.util.function.IntConsumer setSteps) {
     JFrame controlFrame = new JFrame("Controls");
     controlFrame.setLayout(new FlowLayout());

     JButton addAntButton = new JButton("Add Ant");
     addAntButton.addActionListener(e -> addAnt.run());

     JButton removeAntButton = new JButton("Remove Ant");
     removeAntButton.addActionListener(e -> removeAnt.run());

     JButton pauseButton = new JButton("Pause / Resume");
     pauseButton.addActionListener(e -> togglePause.run());

     JSlider speedSlider = new JSlider(1, 50, initialSteps);
     speedSlider.setMajorTickSpacing(10);
     speedSlider.setMinorTickSpacing(1);
     speedSlider.setPaintTicks(true);
     speedSlider.setPaintLabels(true);
     speedSlider.addChangeListener(e -> setSteps.accept(speedSlider.getValue()));

     controlFrame.add(addAntButton);
     controlFrame.add(removeAntButton);
     controlFrame.add(new JLabel("Steps/Tick:"));
     controlFrame.add(speedSlider);
     controlFrame.add(pauseButton);

     controlFrame.setSize(600, 120);
     controlFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     controlFrame.setVisible(true);
 }
}
