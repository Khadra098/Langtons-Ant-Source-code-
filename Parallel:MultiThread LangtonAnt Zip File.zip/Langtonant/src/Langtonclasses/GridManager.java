package Langtonclasses;



import java.awt.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class GridManager {
    private final int gridSize;

    public record CellKey(int x, int y) {}

    private final ConcurrentHashMap<CellKey, Boolean> grid = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<CellKey, Color> coloredGrid = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<CellKey, AtomicInteger> antPositions = new ConcurrentHashMap<>();

    public GridManager(int gridSize) {
        this.gridSize = gridSize;
    }

    public synchronized void moveAnt(Ant ant) {
        CellKey key = new CellKey(ant.x, ant.y);
        boolean isBlack = grid.getOrDefault(key, false);

        if (antPositions.containsKey(key)) {
            ant.direction = Direction.turnAround(ant.direction);
        } else {
            antPositions.put(key, new AtomicInteger(ant.direction));
        }

        ant.direction = isBlack ? Direction.turnRight(ant.direction) : Direction.turnLeft(ant.direction);
        grid.put(key, !isBlack);
        if (!isBlack) {
            coloredGrid.put(key, ant.color);
        }

        switch (ant.direction) {
            case Direction.UP -> ant.y = (ant.y - 1 + gridSize) % gridSize;
            case Direction.RIGHT -> ant.x = (ant.x + 1) % gridSize;
            case Direction.DOWN -> ant.y = (ant.y + 1) % gridSize;
            case Direction.LEFT -> ant.x = (ant.x - 1 + gridSize) % gridSize;
        }

        CellKey newKey = new CellKey(ant.x, ant.y);
        antPositions.put(newKey, new AtomicInteger(ant.direction));
    }

    public ConcurrentHashMap<CellKey, Boolean> getGrid() {
        return grid;
    }

    public ConcurrentHashMap<CellKey, Color> getColoredGrid() {
        return coloredGrid;
    }

    public ConcurrentHashMap<CellKey, AtomicInteger> getAntPositions() {
        return antPositions;
    }
}