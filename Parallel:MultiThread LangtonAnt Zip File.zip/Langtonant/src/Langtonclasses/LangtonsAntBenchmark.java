package Langtonclasses;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class LangtonsAntBenchmark {
    public static void main(String[] args) {
        int[] antCounts = {1, 10, 100, 500};
        int gridSize = 10000;
        int regionSize = 4000;
        int numThreads = Runtime.getRuntime().availableProcessors();
        int steps = 5000;

        System.out.println("=== Parallel Performance Test ===");
        System.out.printf("Grid Size: %dx%d, Threads: %d, Steps: %d%n", gridSize, gridSize, numThreads, steps);
        System.out.println("--------------------------------------------------");

        for (int antCount : antCounts) {
            long timeTaken = runSimulation(gridSize, regionSize, numThreads, antCount, steps);
            double avgStepTime = timeTaken;

            System.out.printf("Ants: %4d | Total Time: %5d ms | Avg per step: %.2f ms%n",
                    antCount, timeTaken, avgStepTime);
        }

        System.out.println("--------------------------------------------------");
        System.out.println("Benchmark complete.");
    }

    private static long runSimulation(int gridSize, int regionSize, int numThreads, int antCount, int steps) {
        GridManager gridManager = new GridManager(gridSize);
        List<Ant> ants = new ArrayList<>();

        for (int i = 0; i < antCount; i++) {
            int x = (int) (Math.random() * gridSize);
            int y = (int) (Math.random() * gridSize);
            Color color = new Color((int)(Math.random() * 0x1000000));
            ants.add(new Ant(x, y, color));
        }

        AntMover antMover = new AntMover(gridManager);
        ParallelEngine engine = new ParallelEngine(numThreads, regionSize, gridSize, ants, antMover);

        long startTime = System.currentTimeMillis();
        for (int i = 0; i < steps; i++) {
            engine.step();
            if ((i + 1) % 1000 == 0) {
                System.out.printf("  [%d ants] Step %d completed...\n", antCount, i + 1);
            }
        }
        long endTime = System.currentTimeMillis();

        return endTime - startTime;
    }
}

