package Langtonclasses;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static boolean isPaused = false;
    private static int stepsPerTick = 10;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // User inputs
            String gridSizeInput = JOptionPane.showInputDialog("Enter grid size (e.g., 500):", "500");
            String antCountInput = JOptionPane.showInputDialog("Enter number of ants (e.g., 1):", "1");
            String totalStepsInput = JOptionPane.showInputDialog("Enter number of simulation steps (e.g., 10000):", "10000");

            int gridSize = Integer.parseInt(gridSizeInput);
            int antCount = Integer.parseInt(antCountInput);
            int totalSteps = Integer.parseInt(totalStepsInput);
            
            int regionSize = gridSize / 20;
            int numThreads = Runtime.getRuntime().availableProcessors();

            GridManager gridManager = new GridManager(gridSize);
            List<Ant> ants = new ArrayList<>();

            for (int i = 0; i < antCount; i++) {
                int x = (int) (Math.random() * gridSize);
                int y = (int) (Math.random() * gridSize);
                Color color = Color.getHSBColor((float) Math.random(), 1f, 1f);
                ants.add(new Ant(x, y, color));
            }

            AntMover mover = new AntMover(gridManager);
            ParallelEngine engine = new ParallelEngine(numThreads, regionSize, gridSize, ants, mover);
            LangtonsAntPanel panel = new LangtonsAntPanel(gridSize, gridManager, ants);

            JFrame frame = new JFrame("Langton's Ant - Parallel");
            frame.add(panel);
            frame.setSize(800, 800);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);

            final int[] stepCounter = {0};

            Timer timer = new Timer(15, e -> {
                if (!isPaused && stepCounter[0] < totalSteps) {
                    for (int i = 0; i < stepsPerTick && stepCounter[0] < totalSteps; i++) {
                        engine.step();
                        stepCounter[0]++;
                    }
                    panel.repaint();
                }
            });
            timer.start();

            ControlPanel.create(frame, ants,
                () -> ants.add(new Ant((int) (Math.random() * gridSize), (int) (Math.random() * gridSize), Color.getHSBColor((float) Math.random(), 1f, 1f))),
                () -> {
                    if (ants.size() > 1) ants.remove(ants.size() - 1);
                    else JOptionPane.showMessageDialog(null, "At least one ant must remain.", "Warning", JOptionPane.WARNING_MESSAGE);
                },
                () -> isPaused = !isPaused,
                stepsPerTick,
                v -> stepsPerTick = v
            );
        });
    }
}
