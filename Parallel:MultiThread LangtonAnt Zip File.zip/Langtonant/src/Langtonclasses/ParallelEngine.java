package Langtonclasses;


import java.util.List;
import java.util.concurrent.ForkJoinPool;

public class ParallelEngine {
 private final ForkJoinPool pool;
 private final int regionSize;
 private final int gridSize;
 private final List<Ant> ants;
 private final AntMover antMover;

 public ParallelEngine(int numThreads, int regionSize, int gridSize, List<Ant> ants, AntMover antMover) {
     this.pool = new ForkJoinPool(numThreads);
     this.regionSize = regionSize;
     this.gridSize = gridSize;
     this.ants = ants;
     this.antMover = antMover;
 }

 public void step() {
     pool.invoke(new RegionTask(0, gridSize, 0, gridSize, regionSize, ants, antMover));
 }
}