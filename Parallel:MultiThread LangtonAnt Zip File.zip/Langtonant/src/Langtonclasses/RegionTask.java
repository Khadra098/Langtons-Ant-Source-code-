package Langtonclasses;


import java.util.List;
import java.util.concurrent.RecursiveAction;

public class RegionTask extends RecursiveAction {
 private final int startX, endX, startY, endY;
 private final int regionSize;
 private final List<Ant> ants;
 private final AntMover antMover;

 public RegionTask(int startX, int endX, int startY, int endY, int regionSize, List<Ant> ants, AntMover antMover) {
     this.startX = startX;
     this.endX = endX;
     this.startY = startY;
     this.endY = endY;
     this.regionSize = regionSize;
     this.ants = ants;
     this.antMover = antMover;
 }

 @Override
 protected void compute() {
     if ((endX - startX) > regionSize * 2 || (endY - startY) > regionSize * 2) {
         int midX = (startX + endX) / 2;
         int midY = (startY + endY) / 2;

         invokeAll(
             new RegionTask(startX, midX, startY, midY, regionSize, ants, antMover),
             new RegionTask(midX, endX, startY, midY, regionSize, ants, antMover),
             new RegionTask(startX, midX, midY, endY, regionSize, ants, antMover),
             new RegionTask(midX, endX, midY, endY, regionSize, ants, antMover)
         );
     } else {
         antMover.moveAnts(ants);
     }
 }
}